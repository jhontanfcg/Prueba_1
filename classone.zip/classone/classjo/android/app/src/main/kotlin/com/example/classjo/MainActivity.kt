package com.example.classjo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
